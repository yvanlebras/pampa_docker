library(testthat)
library(PAMPA)

test_check("PAMPA")
